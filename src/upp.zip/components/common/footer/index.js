import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withNavigation } from 'react-navigation';
import LinearGradient from 'react-native-linear-gradient';
import { Footer, Button, Icon } from 'native-base';

import style from './style';

class AppFooter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activePageRoute: null
    };
  }

  componentDidMount() {
    const { navigation } = this.props;

    navigation.addListener('didFocus', payload => {
      const { state } = payload;

      this.setState({
        ...this.state,
        activePageRoute: state.routeName
      });
    });
  }

  render() {
    const { navigation } = this.props;
    const { activePageRoute } = this.state;

    return (
      <Footer style={style.footer}>
        <LinearGradient style={style.content} colors={style.contentColors} useAngle angle={45}>
          <Button style={style.button} onPress={() => navigation.navigate('Search')}>
            <Icon style={activePageRoute === 'Search' ? style.activeText : {}} name="search" />
          </Button>
          <Button style={style.button} onPress={() => navigation.navigate('Connection')}>
            <Icon style={activePageRoute === 'Connection' ? style.activeText : {}} name="bookmarks" />
          </Button>
          <Button style={style.button} onPress={() => navigation.navigate('Message')}>
            <Icon style={activePageRoute === 'Message' ? style.activeText : {}} name="mail" />
          </Button>
          <Button style={style.button} onPress={() => navigation.navigate('User')}>
            <Icon style={activePageRoute === 'User' ? style.activeText : {}} name="person" />
          </Button>
        </LinearGradient>
      </Footer>
    );
  }
}

AppFooter.defaultProps = {
  navigation: {}
};

AppFooter.propTypes = {
  navigation: PropTypes.object
};

export default withNavigation(AppFooter);
