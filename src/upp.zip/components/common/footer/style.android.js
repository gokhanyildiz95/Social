import { Dimensions } from 'react-native';
import { defaultColors } from '~/config/style';

const { width } = Dimensions.get('window');
export default {
  button: {
    flex: 1,
    width: width / 3,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 0,
    backgroundColor: 'transparent',
    borderColor: 'transparent',
    elevation: 0
  },
  activeText: {
    color: defaultColors.orange
  },
  content: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'stretch'
  },
  contentColors: [defaultColors.bg.halfGrey, defaultColors.bg.darkGrey],
  footer: {
    backgroundColor: '#000',
    borderTopWidth: 0
  }
};
