import React from 'react';
import PropTypes from 'prop-types';
import { TouchableHighlight } from 'react-native';
import { Text, View } from 'native-base';
import { Col, Grid } from 'react-native-easy-grid';
import { Avatar } from '~/components/ui/';

// Style
import style from './style';

const NotificationItem = props => {
  const {
    notification,
    notification: { friend, type, status },
    handlePress
  } = props;
  let typeText = '';

  switch (type) {
    case 1:
      typeText = `Size arkadaşlık isteği gönderdi`;
      break;
    case 2:
      typeText = `Arkadaşlık isteğinizi onayladı`;
      break;
    case 3:
      typeText = `Mesaj gönderdi`;
      break;
  }

  return (
    <TouchableHighlight
      style={{ elevation: 0 }}
      activeOpacity={1}
      underlayColor="transparent"
      onPress={() => handlePress(notification)}
    >
      <View style={style.view}>
        <Grid style={status == 1 ? [style.grid, style.gridRead] : style.grid}>
          <Col style={style.avatar}>
            <Avatar user={friend} small />
          </Col>
          <Col>
            <Text style={style.title}>{friend.fullname}</Text>
            <Text style={style.slug}>{typeText}</Text>
          </Col>
        </Grid>
      </View>
    </TouchableHighlight>
  );
};

NotificationItem.propTypes = {
  notification: PropTypes.object.isRequired,
  handlePress: PropTypes.func.isRequired
};

export default NotificationItem;
