export default {
  radioButtonsContent: {
    flexDirection: "row"
  }
};
