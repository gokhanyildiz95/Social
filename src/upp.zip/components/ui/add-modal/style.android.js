export default {
  profileButtonContinueText: {
    fontSize: 14,
    fontWeight: '600'
  }
};
