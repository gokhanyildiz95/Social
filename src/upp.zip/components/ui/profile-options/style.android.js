export default {
  moreIcon: {
    justifyContent: 'flex-end',
    textAlign: 'right',
    color: '#fff'
  }
};
