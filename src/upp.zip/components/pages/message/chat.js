import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Container, View, Header, Footer, Text, Icon } from 'native-base';
import { FlatList, KeyboardAvoidingView, StatusBar, TouchableHighlight } from 'react-native';
import { Col, Grid } from 'react-native-easy-grid';
import OptionsMenu from 'react-native-options-menu';

import Socket from '~/api/socket';
import { Button, ChatItem, Input } from '~/components/ui/';
import { getUser } from '~/api/user';
import { getChat, setBlockFriend, setUnblockFriend } from '~/api/chat/';
import {
  getChatMessages,
  setChatMessage,
  setReadAllChatMessages,
  setReadChatMessage
} from '~/api/chat-message/';
import ImagePicker from '~/lib/image-picker';
import { getUserPlate } from '~/lib/user';
import { defaultColors } from '~/config/style';

import style from './chat-style';

class Chat extends Component {
  constructor(props) {
    super(props);

    const {
      navigation: {
        state: {
          params: { friend }
        }
      }
    } = props;

    this.state = {
      chat: {},
      chatMessages: [],
      friend,
      form: {
        message: ''
      }
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handlePhotoSubmit = this.handlePhotoSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.messageReceived = this.messageReceived.bind(this);
    this.chatReceived = this.chatReceived.bind(this);
    this.handleImagePicker = this.handleImagePicker.bind(this);
    this.handleBlockFriend = this.handleBlockFriend.bind(this);
    this.handleUnblockFriend = this.handleUnblockFriend.bind(this);
  }

  componentDidMount() {
    this.setFriend();
    this.setChat();
  }

  componentWillUnmount() {
    if (this.socket) {
      this.socket.socket.disconnect();
      this.socket = undefined;
    }
  }

  // Chat idsini alıyoruz eğer yoksa oluşturuluyor
  async setChat() {
    const { friend } = this.state;

    const chat = await getChat({ friendUserId: friend.id });
    await setReadAllChatMessages({ chatId: chat.id });

    this.setState(() => ({
      chat
    }));

    this.getChatMessages();
  }

  // Konuşma geçmişini getirir
  async getChatMessages() {
    const { chat } = this.state;
    const chatMessages = await getChatMessages({
      where: { chatId: chat.id },
      sort: 'createdAt DESC'
    });

    this.setState(() => ({
      chatMessages
    }));

    this.chatMessageActivitySocket();
  }

  // Kullanıcıyı state e tanımlar
  async setFriend() {
    const { friend } = this.state;
    const user = await getUser(friend.id);

    this.setState(() => ({ friend: user }));
  }

  // Fotoğraf seçiciyi çalıştırır
  handleImagePicker() {
    new ImagePicker({
      success: this.handlePhotoSubmit
    });
  }

  // Fotoğraf gönderir
  handlePhotoSubmit({ file: files }) {
    const { friend, chat } = this.state;
    const form = {};

    files.map(file => {
      form.attachments = { filename: file.filename };
    });

    form.receiverId = friend.id;
    form.chatId = chat.id;

    setChatMessage(form);
  }

  // Yeni mesaj gönderildiği zaman mesajı state e tanımlar
  messageReceived(message) {
    const {
      user: { user }
    } = this.props;

    // Mesajın durumunu okundu yapıyor
    if (user.id === message.receiverId) {
      setReadChatMessage({ messageId: message.id });
    }

    this.setState(({ chatMessages }) => {
      chatMessages.unshift(message);
      return {
        chatMessages
      };
    });
  }

  // Mesaj aktivitelerini takip edip kullanıcıyı günceller
  chatMessageActivitySocket() {
    if (this.socket && this.socket.connect) {
      return;
    }
    const { chat } = this.state;
    const {
      user: { user }
    } = this.props;

    this.socket = new Socket({
      connect: socket => {
        // Mesaj aktivitelerini almak izni için kayıt
        socket.get('/subscribe/chat');
        // Mesaj aktivitelerini alır
        socket.on(`chat-message-activity-receive/${chat.id}`, this.messageReceived);
        // Mesaj aktivitelerini alır
        socket.on(`chat-activity-receive/${user.id}`, this.chatReceived);
      }
    });
  }

  // Chat güncellendiğinde state chat'e tanımlar
  chatReceived(chat) {
    const { chat: prevChat } = this.state;

    if (chat.id == prevChat.id) {
      this.setState(() => ({
        chat
      }));
    }
  }

  // Mesaj Gönderir
  handleSubmit() {
    const { form, friend, chat } = this.state;

    if (!form.message) {
      return false;
    }

    form.receiverId = friend.id;
    form.chatId = chat.id;

    setChatMessage(form);
    this.setState(() => ({
      form: {
        message: ''
      }
    }));
  }

  // Message textini günceller
  handleChange(name, text) {
    this.setState(() => ({
      form: {
        message: text
      }
    }));
  }

  // Message textini günceller
  handleCancel() {}

  // Kullanıcıyı bloklar
  handleBlockFriend() {
    const { chat } = this.state;

    setBlockFriend({ chatId: chat.id }).then(updatedChat => {
      this.setState(() => ({
        chat: updatedChat
      }));
    });
  }

  // Kullanıcının bloğunu kaldırır
  handleUnblockFriend() {
    const { chat } = this.state;

    setUnblockFriend({ chatId: chat.id }).then(updatedChat => {
      this.setState(() => ({
        chat: updatedChat
      }));
    });
  }

  // Options menu render
  renderOptionsMenu() {
    const { chat } = this.state;
    const opts = {
      customButton: <Icon name="ellipsis-v" type="FontAwesome" style={style.navIcon} />,
      destructiveIndex: 0,
      options: ['Engelle', 'İptal'],
      actions: [this.handleBlockFriend, this.handleCancel]
    };

    if (chat.status == 2) {
      opts.options = ['Engeli Kaldır', 'İptal'];
      opts.actions = [this.handleUnblockFriend, this.handleCancel];
    }

    return <OptionsMenu {...opts} />;
  }

  // Options menu render
  renderFooter() {
    const {
      user: { user }
    } = this.props;
    const {
      chat,
      form: { message }
    } = this.state;

    return (
      <Footer style={style.footer}>
        {chat.status !== 2 ? (
          <Grid style={style.footerGrid}>
            <Col size={15} style={[style.footerGridCol, style.footerGridFirstCol]}>
              <Button
                size="s"
                icon="add"
                color="blue"
                rounded
                extraStyle={style.plusButton}
                extraIconStyle={style.plusIcon}
                onPress={this.handleImagePicker}
              />
            </Col>
            <Col size={70} style={style.footerGridCol}>
              <Input
                multiline
                value={message}
                onChange={this.handleChange}
                extraStyle={style.messageInputContent}
                extraInputStyle={style.messageInput}
              />
            </Col>
            <Col size={15} style={[style.footerGridCol, style.footerGridLastCol]}>
              <TouchableHighlight onPress={this.handleSubmit} style={style.touchableHighlight}>
                <Icon name="send" type="MaterialIcons" style={style.sendIcon} />
              </TouchableHighlight>
            </Col>
          </Grid>
        ) : user.id == chat.blockedUserId ? (
          <Text style={style.blockText}>Engellendiniz</Text>
        ) : (
          <Text style={style.blockText}>Kullanıcı Engellendi</Text>
        )}
      </Footer>
    );
  }

  render() {
    const {
      navigation,
      user: { user }
    } = this.props;
    const { chatMessages, friend } = this.state;
    const plate = getUserPlate(user);
    const optionsMenu = this.renderOptionsMenu();
    const footer = this.renderFooter();

    return (
      <Container>
        <StatusBar translucent backgroundColor={defaultColors.bg.dark} barStyle="dark-content" />
        <KeyboardAvoidingView behavior="height" style={{ flex: 1 }}>
          <View style={style.headerContainer}>
            <Header style={style.header}>
              <Grid style={style.headerGrid}>
                <Col size={15} style={[style.headerGridCol, style.headerGridFirstCol]}>
                  <Button
                    onPress={() => {
                      navigation.goBack();
                    }}
                    icon="arrow-back"
                    color="transparent"
                    extraIconStyle={style.backButton}
                  />
                </Col>
                <Col size={70} style={style.headerGridCol}>
                  <Text style={style.title}>
                    {user.fullname}
                    {' • '}
                    {plate.name}
                  </Text>
                </Col>
                <Col size={15} style={[style.headerGridCol, style.headerGridLastCol]}>
                  {optionsMenu}
                </Col>
              </Grid>
            </Header>
          </View>
          <View style={style.content}>
            <FlatList
              inverted={-1}
              ref={ref => (this.flatList = ref)}
              extraData={this.state}
              data={chatMessages}
              renderItem={({ item: message, index }) => {
                return <ChatItem key={index} message={message} friend={friend} />;
              }}
              removeClippedSubviews={false}
              enableEmptySections
              keyExtractor={(item, index) => index}
            />
          </View>
          {footer}
        </KeyboardAvoidingView>
      </Container>
    );
  }
}

Chat.propTypes = {
  navigation: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired
};

export default Chat;
