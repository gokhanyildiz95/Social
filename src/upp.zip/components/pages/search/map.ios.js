import React, { Component } from 'react';
import PropTypes from 'prop-types';
import MapView, { Polygon } from 'react-native-maps';
import { getAreaCoordinates } from '~/lib/map';
import { MapMarker } from '~/components/ui/';

class Search extends Component {
  // constructor(props) {
  //   super(props);
  // }

  handleMarkerPress = user => {
    const { handlePress } = this.props;
    handlePress(user);
  };

  render() {
    const { location, users } = this.props;
    const { latitude, longitude } = location;
    let region = {
      latitude: 39.3008015,
      longitude: 34.2965664,
      latitudeDelta: 0.4,
      longitudeDelta: 0.4
    };

    let sqr = false;

    if (latitude && longitude) {
      sqr = getAreaCoordinates({
        latitude,
        longitude
      });

      region.latitude = latitude;
      region.longitude = longitude;
    }

    return (
      <MapView
        style={{ flex: 1 }}
        region={region}
        showsUserLocation
        userLocationAnnotationTitle="Ben"
      >
        {sqr && <Polygon coordinates={sqr.polygon} />}
        {users.map((marker, index) => (
          <MapMarker
            key={index}
            handlePress={this.handleMarkerPress}
            lat={marker.latitude}
            long={marker.longitude}
            text={marker.fullname}
            user={marker}
          />
        ))}
      </MapView>
    );
  }
}

Search.propTypes = {
  handlePress: PropTypes.func.isRequired,
  location: PropTypes.object.isRequired,
  users: PropTypes.array.isRequired
};

export default Search;
