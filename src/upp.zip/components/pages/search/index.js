import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Container, ScrollableTab, Tab, Tabs } from 'native-base';
import { KeyboardAvoidingView, StatusBar } from 'react-native';
import { defaultColors } from '~/config/style';
import { Footer } from '~/components/common/';
import Header from './header';
import TabArea from './tab-area';
import TabSearch from './tab-search';

import style from './style';

class Search extends Component {
  constructor(props) {
    super(props);

    this.state = {
      viewMode: 'list',
      currentTab: 0
    };

    this.handleChangeViewType = this.handleChangeViewType.bind(this);
    this.handleChangeTab = this.handleChangeTab.bind(this);
    this.handlePressNotification = this.handlePressNotification.bind(this);
  }

  handleChangeViewType() {
    const { viewMode } = this.state;
    this.setState({
      ...this.state,
      viewMode: viewMode === 'list' ? 'map' : 'list'
    });
  }

  handlePressNotification() {
    const { navigation } = this.props;

    navigation.navigate('Notification');
  }

  handleChangeTab({ i }) {
    this.setState({
      ...this.state,
      currentTab: i
    });
  }

  render() {
    const { location, navigation, user, notification, isFocused } = this.props;
    const { viewMode, currentTab } = this.state;

    return (
      <Container>
        <StatusBar translucent backgroundColor={defaultColors.bg.dark} barStyle="dark-content" />
        <Header
          location={location}
          viewMode={viewMode}
          currentTab={currentTab}
          notification={notification}
          handlePressNotification={this.handlePressNotification}
          handleChangeViewType={this.handleChangeViewType}
        />
        <KeyboardAvoidingView behavior="height" style={{ flex: 1 }}>
          <Tabs
            renderTabBar={() => (
              <ScrollableTab
                style={style.scrollTab}
                tabsContainerStyle={style.scrollTabsContainer}
                underlineStyle={style.tabUnderline}
              />
            )}
            tabBarUnderlineStyle={style.tabBarUnderline}
            onChangeTab={this.handleChangeTab}
          >
            <Tab
              style={style.tabContent}
              tabStyle={[style.tab, style.firstTab]}
              activeTabStyle={style.activeTab}
              textStyle={style.tabText}
              activeTextStyle={style.activeTabText}
              heading="Ara"
            >
              <TabSearch location={location} user={user} navigation={navigation} />
            </Tab>
            <Tab
              style={style.tabContent}
              tabStyle={style.tab}
              activeTabStyle={style.activeTab}
              textStyle={style.tabText}
              activeTextStyle={style.activeTabText}
              heading="Çevremde?"
            >
              <TabArea
                isFocused={isFocused}
                navigation={navigation}
                location={location}
                user={user}
                viewMode={viewMode}
              />
            </Tab>
          </Tabs>
        </KeyboardAvoidingView>
        <Footer />
      </Container>
    );
  }
}

Search.propTypes = {
  isFocused: PropTypes.bool.isRequired,
  location: PropTypes.object.isRequired,
  notification: PropTypes.object.isRequired,
  navigation: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired
};

export default Search;
