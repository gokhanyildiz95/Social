import React from 'react';
import { Container } from 'native-base';

const SideBar = () => {
  return <Container />;
};

export default SideBar;
