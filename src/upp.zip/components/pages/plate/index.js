import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { ListView, StatusBar } from 'react-native';
import { Content, Container, List, Button, Icon } from 'native-base';

import { getPlate, setPlate, updatePlate, deletePlate } from '~/api/plate';
import { defaultColors } from '~/config/style';
import { PlateItem, AddModal } from '~/components/ui/';
import Header from './header';

// NOTE: Plaka listeme ekranı
class Plate extends Component {
  constructor(props) {
    super(props);

    this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });

    this.state = {
      plateFormShow: false,
      form: {
        name: ''
      }
    };

    this.handleDeletePlate = this.handleDeletePlate.bind(this);
    this.handleSetDefault = this.handleSetDefault.bind(this);
    this.handlePress = this.handlePress.bind(this);
    this.handleFormChange = this.handleFormChange.bind(this);
    this.handlePlateFormClose = this.handlePlateFormClose.bind(this);
    this.handleFormSubmit = this.handleFormSubmit.bind(this);
  }

  componentDidMount() {
    this.setPlates();
  }

  // NOTE: Plakaları çekmek için kullanılır
  async setPlates() {
    const {
      user: { user },
      setUserPlates
    } = this.props;

    const plates = await getPlate({ where: { userId: user.id } });
    setUserPlates(plates);
  }

  // NOTE: Plaka düzenlemek için modeli açar
  handlePress(plate = {}) {
    this.setState(() => ({
      form: plate,
      plateFormShow: true
    }));
  }

  // Formdan gelen verileri state'e ekler
  handleFormChange(name, text) {
    const { form } = this.state;

    form[name] = text;
    this.setState(() => ({
      form
    }));
  }

  // Plaka düzenleme için kulllanılan formu ekranda gösterir
  handlePlateFormClose() {
    this.setState(() => ({
      plateFormShow: false
    }));
  }

  // Plaka düzenleme için kulllanılan formu ekranda gösterir
  async handleFormSubmit() {
    const {
      user: { user }
    } = this.props;
    const { form } = this.state;
    const data = {
      name: form.name,
      userId: user.id
    };

    if (form.id) {
      await updatePlate(form.id, data);
    } else {
      await setPlate(data);
    }

    this.handlePlateFormClose();
    this.setPlates();
  }

  // NOTE: Plaka silme işlemi yapar
  async handleDeletePlate(plate, secId, rowId, rowMap) {
    // NOTE: Listview içindeki satırı kapatıyor
    rowMap[`${secId}${rowId}`].props.closeRow();
    deletePlate(plate.id).then(() => {
      this.setPlates();
    });
  }

  // NOTE: Plaka varsayılan yapma işlemi yapar
  async handleSetDefault(plate, secId, rowId, rowMap) {
    const {
      user: { user }
    } = this.props;
    // NOTE: Listview içindeki satırı kapatıyor
    rowMap[`${secId}${rowId}`].props.closeRow();

    await Promise.all(
      user.plates.map(plateItem => {
        if (plateItem.default) {
          updatePlate(plateItem.id, { default: 0 });
        }
      })
    );

    updatePlate(plate.id, { default: 1 }).then(() => {
      this.setPlates();
    });
  }

  render() {
    const {
      navigation,
      user: { user }
    } = this.props;
    const { form, plateFormShow } = this.state;
    // NOTE: Plate listi ds'e atıyor ?!
    const listData = this.ds.cloneWithRows(user.plates);

    return (
      <Container>
        <StatusBar translucent backgroundColor={defaultColors.bg.dark} barStyle="dark-content" />
        <Header navigation={navigation} handleAdd={this.handlePress} />
        <Content>
          <List
            leftOpenValue={user.plates.length > 1 ? 50 : 0}
            rightOpenValue={user.plates.length > 1 ? -50 : 0}
            dataSource={listData}
            renderRow={plate => <PlateItem plate={plate} handlePress={this.handlePress} />}
            renderLeftHiddenRow={(plate, secId, rowId, rowMap) => (
              <Button
                full
                success
                onPress={() => this.handleSetDefault(plate, secId, rowId, rowMap)}
              >
                <Icon active name="checkmark" />
              </Button>
            )}
            renderRightHiddenRow={(plate, secId, rowId, rowMap) => (
              <Button
                full
                danger
                onPress={() => this.handleDeletePlate(plate, secId, rowId, rowMap)}
              >
                <Icon active name="trash" />
              </Button>
            )}
          />
        </Content>
        <AddModal
          label="Plakanızı yazın (örn: 06AC9878)"
          name="name"
          placeholder="Plaka"
          buttonText={form.id ? 'Düzenle' : 'Ekle'}
          visibility={plateFormShow}
          value={form.name}
          handleFormSubmit={this.handleFormSubmit}
          handleClose={this.handlePlateFormClose}
          handleFormChange={this.handleFormChange}
        />
      </Container>
    );
  }
}

Plate.propTypes = {
  setUserPlates: PropTypes.func.isRequired,
  user: PropTypes.object.isRequired,
  navigation: PropTypes.object.isRequired
};

export default Plate;
