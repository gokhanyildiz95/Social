import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Redirect } from 'react-navigation';
import { Container, Text } from 'native-base';

import Socket from '~/api/socket';
import Notification from '~/lib/notification';

// import style from './style';

class Intro extends Component {
  constructor(props) {
    super(props);

    this.state = {
      redirect: false
    };
  }

  componentDidUpdate(prevProps) {
    const { user, system } = this.props;
    const { system: prevSystem } = prevProps;

    // Storagedaki state load edildi ise
    if (system.loadedState != prevSystem.loadedState) {
      // Login kontrolü yapılıyor
      this.userLoggedInControl();
    }

    if (user.signedIn) {
      this.notificationSocket();
    }
  }

  // Kullanıcı girişi kontrolü
  userLoggedInControl() {
    const { user, setUserInfo, navigation, setNotifications } = this.props;

    // Giriş yapılmamış ise intro sayfasına gönderir
    if (!user.signedIn) {
      navigation.navigate('Home');
      return false;
    }

    // Giriş yapılmış ise bildirimleri ve kullanıcı bilgisini tazeler
    setNotifications({ user: user.user.id });
    setUserInfo();
    // Search sayfasına gönderir
    navigation.navigate('Search');
    // navigation.navigate('User');
  }

  // Anlık bildirimleri günceller
  notificationSocket() {
    if (this.socket && this.socket.connect) {
      return;
    }

    const {
      user: { user },
      navigation,
      setNotifications
    } = this.props;

    const notification = new Notification({ navigation });

    this.socket = new Socket({
      connect: socket => {
        // Notification izni için kayıt
        socket.get('/subscribe/notification');
        // Notificationları alır
        socket.on(`notification-receive/${user.id}`, data => {
          const {
            navigationState: { route }
          } = this.props;

          // Notificationları günceller
          setNotifications({ user: user.id });
          // Gelen notificationı ekranda gösterir
          notification.show(data, route);
        });
      }
    });
  }

  render() {
    const { redirect } = this.state;

    return (
      <Container>
        {redirect && <Redirect to={redirect} />}
        <Text>Loading...</Text>
      </Container>
    );
  }
}

Intro.propTypes = {
  system: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired,
  navigationState: PropTypes.object.isRequired,
  navigation: PropTypes.object.isRequired,
  setUserInfo: PropTypes.func.isRequired,
  setNotifications: PropTypes.func.isRequired
};

export default Intro;
