import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Container, Header, ScrollableTab, Tab, Tabs, Text } from 'native-base';
import { ScrollView, StatusBar, View } from 'react-native';
import { Col, Grid } from 'react-native-easy-grid';
import _ from 'lodash';
import { getUsers } from '~/api/user';

import { defaultColors } from '~/config/style';
import { Footer } from '~/components/common/';
import { UserCard,UserConnectionRequest } from '~/components/ui/';

import style from './style';
import { getFriendRequest } from '../../../api/friend';
        
class Connection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      list: [],
      search: '',
      friends: [],
      friendRequest: []
    };
    this.handlePress = this.handlePress.bind(this);  

  }

  componentDidMount() {
    this.setUserFriends();
    this.setUserFriendRequests();
  }
 
  async setUserFriendRequests() {
    const { user } = this.props;
    const id = user.user.id;
    console.log("USER",user);
    const users = await getFriendRequest({userId:id});
    console.log("Request",users);
    const userIds = [];
      users.forEach(element => {
        console.log("ELEMENT",element);
        if(element.status === 0){
          userIds.push(element.userId);
        }
      });
      console.log("IDS",userIds);
      const userss = await getUsers({ where: { id: userIds } });
      console.log("USERS",userss);

      this.setState(() => ({ friendRequest: userss }));   
  }

  async setUserFriends() {
    const { user } = this.props;
    const a = user.user;
      const userIds = a.friends.map(data => data.friendUserId);
      const users = await getUsers({ where: { id: userIds } });
      this.setState(() => ({ friends: users }));
   }
 
  handlePress(friend) {
    const { navigation } = this.props;
    navigation.push('Profile', { friend });
   }

 
 
  render() {
    const { friends,friendRequest } = this.state;
      return (
      <Container>
        <StatusBar translucent backgroundColor={defaultColors.bg.dark} barStyle="dark-content" />
        <Header style={style.header}>
          <Grid style={style.headerGrid}>
            <Col style={style.headerGridCol}>
              <View>
                <Text style={style.title}>Bağlantılarım</Text>
              </View>
            </Col>
         
          </Grid>
        </Header>
        <Tabs
          renderTabBar={() => (
            <ScrollableTab
              style={style.scrollTab}
              tabsContainerStyle={style.scrollTabsContainer}
              underlineStyle={style.tabUnderline}
            />
          )}
          tabBarUnderlineStyle={style.tabBarUnderline}
        >
          <Tab
            style={style.tabContent}
            tabStyle={[style.tab, style.firstTab]}
            activeTabStyle={[style.activeTab, style.firstActiveTab]}
            textStyle={style.tabText}
            activeTextStyle={style.activeTabText}
            heading="Bağlantı İstekleri"
          >
            <ScrollView style={style.scrollView}>
         
 <View style={style.scrollViewContent}>
              {friendRequest.map(friendRequest => (
                    <UserConnectionRequest 
                    key={friendRequest.id} 
                    user={friendRequest} 
                    handlePress={this.handlePress} 
                      />
                  ))}
              </View>
 </ScrollView>
          </Tab>
          <Tab
            style={style.tabContent}
            tabStyle={style.tab}
            activeTabStyle={style.activeTab}
            textStyle={style.tabText}
            activeTextStyle={style.activeTabText}
            heading="Tüm Bağlantılarım"
          >
            <ScrollView style={style.scrollView}>
              <View style={style.scrollViewContent}>
              {friends.map(friend => (
                    <UserCard key={friend.id} user={friend} handlePress={this.handlePress} />
                  ))}
              </View>
            </ScrollView>
          </Tab>
        </Tabs>
        <Footer />
      </Container>
    );
  }
}

Connection.propTypes = {
  isFocused: PropTypes.bool.isRequired,
  navigation: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired,
};

export default Connection;
