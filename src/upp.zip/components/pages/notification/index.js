import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { ListView, StatusBar } from 'react-native';
import { Content, Container, List, Button, Icon } from 'native-base';

import { defaultColors } from '~/config/style';
import { NotificationItem } from '~/components/ui/';
import Header from './header';

import style from './style';

// Bildirim listeme ekranı
class Notification extends Component {
  constructor(props) {
    super(props);

    this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
    this.handlePress = this.handlePress.bind(this);
  }

  // Notification yönlendirmesi yapar
  handlePress(notification) {
    const { navigation, setReadNotification } = this.props;

    // Bildirimi okundu olarak işaretliyor
    setReadNotification(notification.id);

    // Notification tipi 3 ise chat e yönlendiriyor
    if (notification.type === 3) {
      navigation.navigate('Chat', { friend: notification.friend });
      return;
    }

    // Değilse profile yönleniyor
    navigation.navigate('Profile', { friend: notification.friend });
  }

  // Notification silme işlemi yapar
  async handleDeleteNotification(notification, secId, rowId, rowMap) {
    const { setDeleteNotification } = this.props;

    // Listview içindeki satırı kapatıyor
    rowMap[`${secId}${rowId}`].props.closeRow();
    // Silme isteği gönderiyor
    setDeleteNotification(notification.id);
  }

  render() {
    const {
      notification: { list },
      navigation
    } = this.props;

    // Notification listi ds'e atıyor ?!
    const listData = this.ds.cloneWithRows(list);

    return (
      <Container>
        <StatusBar translucent backgroundColor={defaultColors.bg.dark} barStyle="dark-content" />
        <Header navigation={navigation} />
        <Content>
          <List
            rightOpenValue={-75}
            dataSource={listData}
            renderRow={notification => (
              <NotificationItem notification={notification} handlePress={this.handlePress} />
            )}
            renderRightHiddenRow={(notification, secId, rowId, rowMap) => (
              <Button
                full
                danger
                onPress={_ => this.handleDeleteNotification(notification, secId, rowId, rowMap)}
              >
                <Icon active name="trash" />
              </Button>
            )}
          />
        </Content>
      </Container>
    );
  }
}

Notification.propTypes = {
  user: PropTypes.object.isRequired,
  notification: PropTypes.object.isRequired,
  setReadNotification: PropTypes.func.isRequired,
  setNotifications: PropTypes.func.isRequired,
  setDeleteNotification: PropTypes.func.isRequired,
  navigation: PropTypes.object.isRequired
};

export default Notification;
