import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Container, Text, View } from 'native-base';
import { StatusBar, ImageBackground, ScrollView } from 'react-native';

import { getUsers } from '~/api/user';
import { defaultColors } from '~/config/style';
import { Footer } from '~/components/common/';
import { Row, Grid } from 'react-native-easy-grid';
import { Avatar, Button, UserCard, ProfileTabs, ProfileOptions } from '~/components/ui/';
import { getUserPlate } from '~/lib/user';
 
import style from './style';

class Profile extends Component {
  constructor(props) {
    super(props);

    this.state = {
      friends: []
    };
    this.handlePress = this.handlePress.bind(this);
  }

  componentDidMount() {
    this.setUserFriends();
  }

  async setUserFriends() {
    const { user } = this.props;
    const userIds = user.friends.map(data => data.friendUserId);
    const users = await getUsers({ where: { id: userIds } });

    this.setState(() => ({ friends: users }));
  }

  // Seçilen kullanıcının profil sayfasına yönlendirir
  handlePress(friend) {
    const { navigation } = this.props;
    navigation.push('Profile', { friend });
  }

  // Arkadaş ekle butonu render fonksiyonu
  renderButton() {
    const { acceptToRequest, friendStatus, navigation, user } = this.props;
    let props = {
      size: 'xl',
      extraTextStyle: style.buttonText
    };

    // Eğer arkadaşlık isteği gelmiş ise
    if (friendStatus == 1) {
      props = {
        ...props,
        onPress: acceptToRequest,
        color: 'darkBlueToTurquoise',
        text: 'İsteği Onayla'
      };

      return <Button {...props} />;
    }

    props = {
      ...props,
      onPress: () => navigation.navigate('Chat', { friend: user }),
      color: 'darkBlueToTurquoise',
      text: 'Mesaj At'
    };

    return <Button {...props} />;
  }

  render() {
    const button = this.renderButton();
    const { friends } = this.state;
    const { user, handleRefreshUserStates, favoriteCount, favorited, blocked } = this.props;
    const plate = getUserPlate(user);

    return (
      <React.Fragment>
        <StatusBar translucent backgroundColor={defaultColors.bg.dark} barStyle="light-content" />
        <Container>
          <Grid>
            <Row size={50}>
              <ImageBackground
                style={style.avatarContent}
                source={require('~/assets/login-bg.png')}
              >
                <View style={style.moreIconTouchableHighlight}>
                  <ProfileOptions
                    user={user}
                    handleRefresh={handleRefreshUserStates}
                    favorited={favorited}
                    blocked={blocked}
                  />
                </View>
                <View style={style.avatarContentView}>
                  <Avatar large user={user} />
                  <Text style={style.title}>{plate.name}</Text>
                  <Text style={style.subTitle}>{user.fullname}</Text>
                  <View style={[style.buttonView, style.messageButtonView]}>{button}</View>
                </View>
              </ImageBackground>
            </Row>
            <Row size={50} style={style.listContent}>
              <View style={style.tabContent}>
                <ProfileTabs favoriteCount={favoriteCount} user={user} theme="dark" />
              </View>
              <ScrollView style={style.scrollView}>
                <View style={style.scrollViewContent}>
                  {friends.map(friend => (
                    <UserCard key={friend.id} user={friend} handlePress={this.handlePress} />
                  ))}
                </View>
              </ScrollView>
            </Row>
          </Grid>
          <Footer />
        </Container>
      </React.Fragment>
    );
  }
}

Profile.propTypes = {
  acceptToRequest: PropTypes.func.isRequired,
  navigation: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired,
  friendStatus: PropTypes.number.isRequired,
  refreshRelation: PropTypes.func.isRequired,

  handleRefreshUserStates: PropTypes.func.isRequired,
  favoriteCount: PropTypes.number.isRequired,
  favorited: PropTypes.bool.isRequired,
  blocked: PropTypes.bool.isRequired
};

export default Profile;
