import { defaultColors, shadow } from '~/config/style';

export default {
  header: {
    justifyContent: 'flex-end',
    borderBottomWidth: 0,
    backgroundColor: 'transparent',
    paddingRight: 30
  },
  headerGridContent: {
    width: '100%',
    height: 20,
    flex: 0,
    marginBottom: 40,
    justifyContent: 'center',
    alignItems: 'center'
  },
  backButton: {},
  backIcon: {
    color: defaultColors.white,
    fontSize: 20
  },
  headerTitle: {
    color: defaultColors.white,
    textAlign: 'center',
    fontSize: 14
  },
  moreIconTouchableHighlight: {
    width: 50,
    height: 50,
    position: 'absolute',
    right: 20,
    top: 40,
    zIndex: 9
  },
  avatarContent: {
    width: '100%',
    height: '100%',
    ...shadow,
    shadowOpacity: 0.1,
    shadowOffset: {
      width: 0,
      height: 5
    }
  },
  avatarContentView: {
    padding: 25,
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center'
  },
  avatarContentViewCenter: {
    padding: 25,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  avatarContentViewBetween: {
    padding: 25,
    paddingBottom: 50,
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center'
  },
  title: {
    marginTop: 15,
    marginBottom: 5,
    fontSize: 22,
    fontWeight: '600',
    color: defaultColors.white
  },
  subTitle: {
    fontSize: 13,
    fontWeight: '300',
    color: defaultColors.white
  },
  containerButtons: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  buttonView: {
    height: 50,
    width: '49%',
    marginTop: 25,
    marginBottom: 15
  },
  messageButtonView: {
    marginTop: 35,
    marginBottom: 0
  },
  buttonText: {
    fontSize: 16
  },
  tabContent: {
    padding: 25,
    paddingBottom: 0
  },
  lockedArea: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center'
  },
  lockIcon: {
    color: defaultColors.grey,
    fontSize: 22
  },
  lockText: {
    color: defaultColors.grey,
    fontSize: 13,
    marginTop: 10
  },
  listContent: {
    flexDirection: 'column'
  },
  scrollView: {
    flex: 1
  },
  scrollViewContent: {
    flex: 1,
    padding: 15,
    paddingTop: 20
  },
  avatarCarouselContent: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  avatarIcons: {
    fontSize: 16,
    color: defaultColors.grey,
    marginLeft: 10,
    marginRight: 10
  },
  avatarIconLeft: {},
  avatarIconRight: {
    fontSize: 20
  },
  profileAddArea: {
    flexDirection: 'column',
    justifyContent: 'space-around',
    padding: 40,
    paddingTop: 20,
    paddingBottom: 20
  },
  profileButtonText: {
    fontSize: 14,
    fontWeight: '400'
  },
  profileButtonContinueText: {
    fontSize: 14,
    fontWeight: '600'
  },
  profileButtonTextGrey: {
    fontSize: 14,
    fontWeight: '400',
    color: defaultColors.grey
  },
  profileButtonIcon: {
    fontSize: 16,
    width: 50,
    textAlign: 'center',
    left: 20
  },
  otherInputContent: {
    height: 45,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd'
  },
  otherInputIconContent: {
    width: 50,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center'
  },
  otherInputIcon: {
    fontSize: 20,
    color: defaultColors.grey
  },
  otherInputText: {
    fontSize: 14
  },
  otherInput: {
    fontSize: 12,
    color: defaultColors.grey,
    marginTop: 2
  },
  reasonText: {
    color: defaultColors.white,
    marginBottom: 20,
    fontSize: 14
  }
};
