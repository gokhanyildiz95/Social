import React from 'react';
import PropTypes from 'prop-types';
import { Container, Content, View } from 'native-base';
import { StatusBar, Image, Text } from 'react-native';
import Carousel from 'react-native-looped-carousel';
import { Button } from '~/components/ui/';
import { Row, Grid } from 'react-native-easy-grid';
import { defaultColors } from '~/config/style';

import style from './style';

const Home = props => {
  const { navigation } = props;
  return (
    <Container>
      <StatusBar translucent backgroundColor={defaultColors.bg.dark} barStyle="light-content" />
      <Grid>
        <Row size={65}>
          <Carousel
            delay={5000}
            autoplay
            style={style.carousel}
            bullets
            bulletsContainerStyle={style.bulletsContainerStyle}
            bulletStyle={style.bulletStyle}
            chosenBulletStyle={style.chosenBulletStyle}
          >
            <View style={style.carouselItem}>
              <Grid>
                <Row style={style.imageRow} size={75}>
                  <View style={style.imageContent}>
                    <Image style={style.image} source={require('~/assets/intro-1.png')} />
                  </View>
                </Row>
                <Row size={25}>
                  <View style={style.textContent}>
                    <Text style={style.text}>Social Traffic ile ister sosyalleş</Text>
                  </View>
                </Row>
              </Grid>
            </View>
            <View style={style.carouselItem}>
              <Grid>
                <Row style={style.imageRow} size={75}>
                  <View style={style.imageContent}>
                    <Image style={style.image} source={require('~/assets/intro-2.png')} />
                  </View>
                </Row>
                <Row size={25}>
                  <View style={style.textContent}>
                    <Text style={style.text}>İster kurallara uymayanları uyar</Text>
                  </View>
                </Row>
              </Grid>
            </View>
            <View style={style.carouselItem}>
              <Grid>
                <Row style={style.imageRow} size={75}>
                  <Grid>
                    <Row size={75} />
                    <Row style={{ backgroundColor: defaultColors.bg.white }} size={25} />
                  </Grid>
                  <View style={[style.imageContent, style.lastImageContent]}>
                    <Image
                      style={[style.image, style.lastImage]}
                      source={require('~/assets/intro-3.png')}
                    />
                  </View>
                </Row>
                <Row size={25}>
                  <View style={style.textContent}>
                    <Text style={style.text}>İster etrafındaki araçları gör</Text>
                  </View>
                </Row>
              </Grid>
            </View>
          </Carousel>
        </Row>
        <Row size={35}>
          <Content style={style.buttonContent}>
            <Button
              color="orangeToYellow"
              rounded
              extraStyle={{ marginTop: 10 }}
              text="Üye Ol"
              onPress={() => navigation.navigate('Register')}
            />
            <Text style={style.orText}>ya da</Text>
            <Button
              bordered
              color="orangeToYellow"
              rounded
              extraStyle={{ marginTop: 10 }}
              text="Hesabın mı var?"
              onPress={() => navigation.navigate('Login')}
            />
          </Content>
        </Row>
      </Grid>
    </Container>
  );
};

Home.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default Home;
