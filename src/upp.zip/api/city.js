import axios from '~/lib/axios';

export default function getCity(params = {}) {
  return axios()
    .get(`city`, { params })
    .then(result => result.data);
}
